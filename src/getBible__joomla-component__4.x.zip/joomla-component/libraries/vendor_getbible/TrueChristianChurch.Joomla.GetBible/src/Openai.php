<?php
/**
 * @package    GetBible
 *
 * @created    30th May, 2023
 * @author     Llewellyn van der Merwe <https://dev.vdm.io>
 * @git        GetBible <https://git.vdm.dev/getBible>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace TrueChristianChurch\Joomla\GetBible;


use Joomla\DI\Container;
use TrueChristianChurch\Joomla\GetBible\Service\Openai as Api;
use TrueChristianChurch\Joomla\Openai\Service\Utilities;
use TrueChristianChurch\Joomla\GetBible\Service\Data;
use TrueChristianChurch\Joomla\GetBible\Service\AI;
use TrueChristianChurch\Joomla\GetBible\Service\Model;
use TrueChristianChurch\Joomla\GetBible\Service\Database;
use TrueChristianChurch\Joomla\Interfaces\FactoryInterface;


/**
 * Openai Factory
 * 
 * @since 3.2.0
 */
abstract class Openai implements FactoryInterface
{
	/**
	 * Global Package Container
	 *
	 * @var     Container
	 * @since 3.2.0
	 **/
	protected static $container = null;

	/**
	 * Get any class from the package container
	 *
	 * @param   string  $key  The container class key
	 *
	 * @return  Mixed
	 * @since 3.2.0
	 */
	public static function _($key)
	{
		return self::getContainer()->get($key);
	}

	/**
	 * Get the global package container
	 *
	 * @return  Container
	 * @since 3.2.0
	 */
	public static function getContainer(): Container
	{
		if (!self::$container)
		{
			self::$container = self::createContainer();
		}

		return self::$container;
	}

	/**
	 * Create a container object
	 *
	 * @return  Container
	 * @since 3.2.0
	 */
	protected static function createContainer(): Container
	{
		return (new Container())
			->registerServiceProvider(new Api())
			->registerServiceProvider(new Utilities())
			->registerServiceProvider(new Data())
			->registerServiceProvider(new AI())
			->registerServiceProvider(new Model())
			->registerServiceProvider(new Database());
	}
}

