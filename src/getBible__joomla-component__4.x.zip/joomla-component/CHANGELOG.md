# v4.0.12

- Add PHP check on installation.
- Add Database check on installation.

# v4.0.11

- Moved all library classes away from default Namespace and Folder path to avoid collusion on outdated classes.

# v4.0.10

- Update getBible loader to version 3.1.0

# v4.0.9

- Correct the url encoding to json_encode for none Latin languages.
- Fix type cast validation on search page.

# v4.0.8

- Restore router functions.

# v4.0.7

- Fix missing token variable in ajax call 

# v4.0.6

- Fix an Ajax input typo. 

# v4.0.5

- Add option to target MySQL 8+ with the search regex.

# v4.0.4

- Fix the spl_autoload_register function to load all the needed namespace. That was remove in the last update (sorry).

# v4.0.3

- Fix canDelete to correctly use published.
- Add default 1 to version field to make sure the versioning feature works as expected.

# v4.0.2

- Fix Daily Light Deprecated code.
- Fix Daily Scripture Deprecated code.

# v4.0.1

- First stable back-end and front-end release towards Joomla 4

# v4.0.0

- Moved to Joomla 4

# v3.0.9

- Add PHP check on installation.
- Add Database check on installation.