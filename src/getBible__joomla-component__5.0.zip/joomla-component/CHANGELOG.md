# v5.0.1

- First stable back-end and front-end release towards Joomla 4 and 5

# v5.0.0

- Moved to Joomla 4 and 5

# v3.0.2

- More namespace updates.

# v3.0.1

-  Fix missing use statement in app model.