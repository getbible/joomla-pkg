# v5.0.0

- Moved to Joomla 4 and 5