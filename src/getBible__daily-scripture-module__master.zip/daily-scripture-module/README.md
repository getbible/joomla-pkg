# Dailyscripture (1.1.5)

Display the daily scripture from [https://git.vdm.dev/christian/daily-scripture](https://git.vdm.dev/christian/daily-scripture).

> Support can be found at our [community support area](https://git.vdm.dev/getBible/support).

# Build Details

+ *Company*: [Vast Development Method](https://getbible.net)
+ *Author*: [Llewellyn van der Merwe](mailto:joomla@vdm.io)
+ *Name*: [Dailyscripture](https://getbible.net)
+ *First Build*: 3rd December, 2015
+ *Last Build*: 26th July, 2023
+ *Version*: 1.1.5
+ *Copyright*: Copyright (C) 2015. All Rights Reserved
+ *License*: GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html

> This **module** was build with a Joomla [Automated Component Builder](https://www.joomlacomponentbuilder.com).
> Developed by [Llewellyn van der Merwe](mailto:joomla@vdm.io)