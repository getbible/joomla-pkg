<?php
/*----------------------------------------------------------------------------------|  io.vdm.dev  |----/
			Vast Development Method
/-------------------------------------------------------------------------------------------------------/

    @package    getBible.net

    @created    2015-12-03 01:42:15
    @author     Llewellyn van der Merwe <https://getbible.life>
    @git        Get Bible <https://git.vdm.dev/getBible>
    @github     Get Bible <https://github.com/getBible>
    @support    Get Bible <https://git.vdm.dev/getBible/support>
    @copyright  Copyright (C) 2015. All Rights Reserved
    @license    GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html

/------------------------------------------------------------------------------------------------------*/

use Joomla\CMS\Layout\LayoutHelper;

// No direct access to this file
defined('_JEXEC') or die;

$displayData = [
	'textPrefix' => 'COM_GETBIBLE_TAGGED_VERSES',
	'formURL'    => 'index.php?option=com_getbible&view=tagged_verses',
	'icon'       => 'icon-tags-2',
];

if ($this->user->authorise('tagged_verse.create', 'com_getbible'))
{
	$displayData['createURL'] = 'index.php?option=com_getbible&task=tagged_verse.add';
}

echo LayoutHelper::render('joomla.content.emptystate', $displayData);
