# v5.0.9

- Correct the url encoding to json_encode for none Latin languages.
- Fix type cast validation on search page.

# v5.0.8

- Fix wrong class naming.

# v5.0.7

- Fix missing token variable in ajax call 

# v5.0.6

- Fix an Ajax input typo. 

# v5.0.5

- Add option to target MySQL 8+ with the search regex.

# v5.0.4

- Fix the spl_autoload_register function to load all the needed namespace. That was remove in the last update (sorry).

# v5.0.3

- Fix canDelete to correctly use published.
- Add default 1 to version field to make sure the versioning feature works as expected.

# v5.0.2

- Fix Daily Light Deprecated code.
- Fix Daily Scripture Deprecated code.

# v5.0.1

- First stable back-end and front-end release towards Joomla 4 and 5

# v5.0.0

- Moved to Joomla 4 and 5

# v4.0.9

- Correct the url encoding to json_encode for none Latin languages.
- Fix type cast validation on search page.

# v3.0.6

- Correct the url encoding to json_encode for none Latin languages.
- Fix type cast validation on search page.