# Get Bible (5.0.16)

 ![Get Bible image](https://git.vdm.dev/getBible/joomla-component/raw/branch/5.0/admin/assets/images/vdm-component.jpg "GetBible")

Welcome to the next level of scripture engagement - The Bible for Joomla! Our purpose is to bring the Word of God to every person, in their native language, entirely free. This isn't just a typical extension; it's a groundbreaking tool developed to span language divides and deliver a rich, customizable Bible study experience to users worldwide.

With an impressive array of 80 translations, our Joomla extension allows people from all corners of the globe to read, comprehend, and meditate on the Holy Scriptures in their preferred language. Moreover, we offer the unique opportunity for individuals to host the Bible on their own website, further extending the reach of the Word.

We've integrated robust features such as note-taking, tagging, and a search function, to enhance your interaction with the Scriptures. This allows users to immerse themselves in the text, crafting a personal journey through the Bible that can be revisited in future sessions. Furthermore, our innovative linker system assigns each visitor a unique identifier (GUID) - no login required. This means you can create notes, select favorite verses, and even share sessions, while maintaining control over your personalized content.

A distinctive feature of our application is the integration with OpenAI. This advanced capability allows website owners to create custom prompts to interact with OpenAI using text from any translation. This function allows you to ask questions, gain clarity, and deepen your understanding of the Scriptures in an engaging and user-friendly manner.

In essence, The Bible for Joomla is designed to transform how the Word of God is shared, studied, and comprehended. Its comprehensive features, combined with a user-friendly interface, make it an essential tool for individuals, churches, and website owners alike. Join us on this journey of faith as we make the wisdom and guidance of the Scriptures accessible to all, one verse, one language, and one website at a time.

# Build Details

+ *Company*: [Vast Development Method](https://getbible.life)
+ *Author*: [Llewellyn van der Merwe](mailto:joomla@vdm.io)
+ *Name*: [Get Bible](https://getbible.life)
+ *First Build*: 3rd December, 2015
+ *Last Build*: 18th November, 2025
+ *Version*: 5.0.16
+ *Copyright*: Copyright (C) 2015. All Rights Reserved
+ *License*: GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html

## Build Time

**840 Hours** or **105 Eight Hour Days** (actual time the author saved -
due to [Automated Component Builder](https://www.joomlacomponentbuilder.com))

> (if creating a folder and file took **5 seconds** and writing one line of code took **10 seconds**,
> never making one mistake or taking any coffee break.)

+ *Line count*: **317036**
+ *File count*: **2310**
+ *Folder count*: **220**

**546 Hours** or **68 Eight Hour Days** (the actual time the author spent)

> (with the following break down:
> **debugging @210hours** = codingtime / 4;
> **planning @117hours** = codingtime / 7;
> **mapping @84hours** = codingtime / 10;
> **office @134hours** = codingtime / 6;)

**1386 Hours** or **173 Eight Hour Days**
(a total of the realistic time frame for this project)

> (if creating a folder and file took **5 seconds** and writing one line of code took **10 seconds**,
> with the normal everyday realities at the office, that includes the component planning, mapping & debugging.)

Project duration: **34.6 weeks** or **7.2 months**

> This **component** was build with a Joomla [Automated Component Builder](https://www.joomlacomponentbuilder.com).
> Developed by [Llewellyn van der Merwe](mailto:joomla@vdm.io)

## Donations

If you want to support this project, please consider donating:
* Open Collective: [Joomla-Component-Builder](https://opencollective.com/Joomla-Component-Builder)