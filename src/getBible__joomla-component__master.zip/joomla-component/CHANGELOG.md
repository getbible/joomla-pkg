# v2.0.1

- New System Architecture as to how Scripture is added
- New Application Page (Bible Page)
- New Linker (anonymous users) system
- SEO for each chapter of the Bible
- New Easy Sharing System
- New Tagging system
- New Notes system
- New Search system
- Integration with OpenAI

# v2.0.2

- Adds missing Marked JS file