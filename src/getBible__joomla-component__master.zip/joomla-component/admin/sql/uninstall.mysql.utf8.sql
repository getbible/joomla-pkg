DROP TABLE IF EXISTS `#__getbible_linker`;
DROP TABLE IF EXISTS `#__getbible_note`;
DROP TABLE IF EXISTS `#__getbible_tagged_verse`;
DROP TABLE IF EXISTS `#__getbible_prompt`;
DROP TABLE IF EXISTS `#__getbible_open_ai_response`;
DROP TABLE IF EXISTS `#__getbible_open_ai_message`;
DROP TABLE IF EXISTS `#__getbible_password`;
DROP TABLE IF EXISTS `#__getbible_tag`;
DROP TABLE IF EXISTS `#__getbible_translation`;
DROP TABLE IF EXISTS `#__getbible_book`;
DROP TABLE IF EXISTS `#__getbible_chapter`;
DROP TABLE IF EXISTS `#__getbible_verse`;

